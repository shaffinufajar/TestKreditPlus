﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoalProgrammingKreditPlus_Shaffiani
{
    class Program
    {
        static void Main(string[] args)
        {
            // No 1 :
            int a = 5;
            int b = 3;

            Console.WriteLine("Nilai awal \n a : " + a + " , b : " + b);
            a = b + a;
            b = a - b;
            a = a - b;

            Console.WriteLine("Nilai sesudah diubah \n a : " + a + " , b : " + b);

            // No 2 :
            int[] x = { 20, 10, 50, 46, 26, 87, 25, 5, 97, 24 };

            Console.WriteLine("\nUrutan awal array x :");
            foreach (int item in x)
            {
                Console.WriteLine(item);
            }

            int temp = 0;

            for (int i = 0; i < x.Length; i++)
            {
                for (int j = 0; j < x.Length; j++)
                {
                    if (x[i] <= x[j])
                    {
                        temp = x[j];
                        x[j] = x[i];
                        x[i] = temp;
                    }
                }
            }
            Console.WriteLine("\nUrutan array x sesudah diurutkan :");
            foreach (int item in x)
            {
                Console.WriteLine(item);
            }


        }
    }
}
